CREATE TRIGGER change_user_mess_num
AFTER INSERT ON message
FOR EACH ROW
  update user set mess_num=mess_num+1 where id=new.mess_to_id;
